﻿namespace harsh
{
    internal class Data
    {
        public string FAN_one { get; set; }
        public string FAN_two { get; set; }
        public string FAN_three { get; set; }
        public string FAN_four { get; set; }
        public string FAN_five { get; set; }
        public string FAN_six { get; set; }
        public string FAN_seven { get; set; }
        public string FAN_eight { get; set; }
        public string FAN_nine { get; set; }
        public string FAN_ten { get; set; }
        public string FAN_eleven { get; set; }
        public string FAN_twelve { get; set; }
        public string FAN_thirteen { get; set; }
        public string FAN_fourteen { get; set; }
        public string FAN_fifteen { get; set; }
    }
}