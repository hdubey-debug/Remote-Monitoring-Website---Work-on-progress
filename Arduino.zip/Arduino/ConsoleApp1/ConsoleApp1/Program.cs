﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
   
        class Program
        {
            public class PointXY
            {
                public double X;
                public double Y;
            }
            static void Main(string[] args)
            {
                PointXY A = new PointXY();
                PointXY B = new PointXY();
                PointXY C = new PointXY();



                A.X = 1;

                A.Y = 2;
                B.X = 3;
                B.Y = 4;
                C = A;

                C.X += 4;
                C.Y += 4;
            System.Console.WriteLine(
            A.X + ", " + A.Y + ", " + B.X + ", " + B.Y + ", " + C.X + ", " + C.Y);
            System.Console.ReadKey();
            }
        }
    
}
