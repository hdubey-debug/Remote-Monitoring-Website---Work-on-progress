﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;


namespace harsh
{
    public partial class Form1 : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "T7zOPUCpZYuAEXrpzW58q8XtCVmZWxeVGL8TcFUt",
            BasePath = "https://status-7262f.firebaseio.com/"
        };

        IFirebaseClient client;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);

            if (client != null)
            {
                MessageBox.Show("Connection is established");
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            var data = new Data
            {
                FAN_one = textBox1.Text,
                FAN_two = textBox2.Text,
                FAN_three = textBox3.Text,
                FAN_four = textBox4.Text,
                FAN_five = textBox5.Text,
                FAN_six = textBox6.Text,
                FAN_seven = textBox7.Text,
                FAN_eight = textBox8.Text,
                FAN_nine = textBox9.Text,
                FAN_ten = textBox10.Text,
                FAN_eleven = textBox11.Text,
                FAN_twelve = textBox12.Text,
                FAN_thirteen = textBox13.Text,
                FAN_fourteen = textBox14.Text,
                FAN_fifteen = textBox15.Text


            };

            SetResponse response = await client.SetTaskAsync("Information/"+textBox1.Text,data);
            Data result = response.ResultAs<Data>();

            MessageBox.Show("Data Inserted");
        }
    }
}
